Uses JQuerry (1.4.2)


Uses Thickbox

- thickbox.js
- thickbox-noconflict.js (to be used with DWR)

JQueryFileTree

jquery.friendurl.min.js

- jqueryFileTree.js

Uses DWR

- jquery.gallerific.min.js

Live Validation

- livevalidation_standalone.compressed.js