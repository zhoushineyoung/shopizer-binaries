jquery ui jquery-ui-1.8.5

picked from bundled folders libraries of interest