@@sql/shopizer_schema_oracle.sql
ALTER SESSION set NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';
@@sql/data/shopizer_data.sql
@@sql/data/shopizer_modules.sql
@@sql/data/shopizer_merchant_data.sql
@@sql/data/decotemplates.sql
commit;