INSERT INTO CORE_MODULES_SERVICES VALUES(200,10,'decotemplate','XX',1,'Deco trends store front template','/storefronttemplates/decotrendstemplate.jpg',1,0,0,'','','','','','','','','',0);

insert into MODULE_CONFIGURATION (
  CONFIGURATION_MODULE,
  CONFIGURATION_KEY,
  COUNTRY_ISO_CODE_2,
  CONFIGURATION_VALUE
) values
('decotemplate','largeimagewidth','XX','168');

insert into MODULE_CONFIGURATION (
  CONFIGURATION_MODULE,
  CONFIGURATION_KEY,
  COUNTRY_ISO_CODE_2,
  CONFIGURATION_VALUE
) values
('decotemplate','largeimageheight','XX','140');


insert into MODULE_CONFIGURATION (
  CONFIGURATION_MODULE,
  CONFIGURATION_KEY,
  COUNTRY_ISO_CODE_2,
  CONFIGURATION_VALUE
) values
('decotemplate','smallimagewidth','XX','50');


insert into MODULE_CONFIGURATION (
  CONFIGURATION_MODULE,
  CONFIGURATION_KEY,
  COUNTRY_ISO_CODE_2,
  CONFIGURATION_VALUE
) values
('decotemplate','smallimageheight','XX','42');



insert into MODULE_CONFIGURATION (
  CONFIGURATION_MODULE,
  CONFIGURATION_KEY,
  COUNTRY_ISO_CODE_2,
  CONFIGURATION_VALUE
) values
('decotemplate','listingitemsquantity','XX','6');


insert into MODULE_CONFIGURATION (
  CONFIGURATION_MODULE,
  CONFIGURATION_KEY,
  COUNTRY_ISO_CODE_2,
  CONFIGURATION_VALUE
) values
('decotemplate','content-decotemplate-product','XX','100');

insert into MODULE_CONFIGURATION (
  CONFIGURATION_MODULE,
  CONFIGURATION_KEY,
  COUNTRY_ISO_CODE_2,
  CONFIGURATION_VALUE
) values
('decotemplate','content-decotemplate-fearured','XX','101');

insert into MODULE_CONFIGURATION (
  CONFIGURATION_MODULE,
  CONFIGURATION_KEY,
  COUNTRY_ISO_CODE_2,
  CONFIGURATION_VALUE
) values
('decotemplate','banner','XX','900');

insert into MODULE_CONFIGURATION (
  CONFIGURATION_MODULE,
  CONFIGURATION_KEY,
  COUNTRY_ISO_CODE_2,
  CONFIGURATION_VALUE
) values
('decotemplate','slider','XX','730px x 275px');